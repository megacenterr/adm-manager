fail2ban.client.configparserinc module
======================================

.. automodule:: fail2ban.client.configparserinc
    :members:
    :undoc-members:
    :show-inheritance:
