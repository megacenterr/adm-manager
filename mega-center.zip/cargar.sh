#!/bin/bash
rm -f install.sh
clear
sudo dpkg-reconfigure tzdata
adm

