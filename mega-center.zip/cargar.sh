#!/bin/bash
rm -f install.sh
rm -f installd.sh
rm -f instalador.sh
rm -f instalador2.sh
clear
sudo dpkg-reconfigure tzdata
adm

